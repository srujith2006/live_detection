# person segmentation > 2023-09-07 8:27am
https://universe.roboflow.com/trijicon/person-segmentation-klcnv

Provided by a Roboflow user
License: CC BY 4.0

